﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IIdentificable
    {
        string Id { get; }

    }
}
